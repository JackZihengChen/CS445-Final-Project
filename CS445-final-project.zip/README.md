# CS445-Final-Project, SP22
### ruisil3, xiaosen2, zihengc2
Organization:  
- Main code: `CS445 Final Project.ipynb`  
- Textures used for generating: `/textures`  
- Input pictures: `/samples`
- Textures generated using simple method: `/generated_simple`  
- Textures generated using seam finding method: `/generated_seam`  
- Sources of textures used: `sources.md`
