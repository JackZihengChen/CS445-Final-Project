#### Sources:
- [purple.jpg](https://unsplash.com/photos/bU8TeXhsPcY)  
![](textures/purple-min.jpg)

- [yellow.jpg](https://pixabay.com/illustrations/yellow-white-cream-wedding-card-6556408/)  
![](textures/yellow-min.jpg)

- [orange.jpg](https://unsplash.com/photos/CZ98fpZL4fs)  
![](textures/orange-min.jpg)

- [red.jpg](https://cn.depositphotos.com/73398859/stock-illustration-seamless-red-geometric-background.html)  
![](textures/red-min.jpg)  

- [green.jpg](https://unsplash.com/photos/C2PCa6DhlYE)  
![](textures/green-min.jpg)

- [navy.jpg](https://unsplash.com/photos/JQcMFXSj6XY)  
![](textures/navy-min.jpg)

- [cyan.jpg](https://unsplash.com/photos/m7IGjPQGgRo)  
![](textures/cyan-min.jpg)

- [opal.jpg](https://unsplash.com/photos/J9NDmBVhN04)  
![](textures/opal-min.jpg)

- [black.jpg](https://unsplash.com/photos/oQbLeq4nOek)  
![](textures/black-min.jpg)

- [waves.jpg](https://unsplash.com/photos/UD5drKd4H6w)  
![](textures/waves-min.jpg)

- [hemp](https://unsplash.com/photos/R_k6kaHhHnY)  
![](textures/hemp-min.jpg)

- [cloud](https://unsplash.com/photos/MHNjEBeLTgw)  
![](textures/cloud.jpg)

- [concrete](https://unsplash.com/photos/0SIQ3DpQCcs)  
![](textures/concrete.jpg)

- [concrete-dark](https://unsplash.com/photos/0SIQ3DpQCcs)  
![](textures/concrete-dark.jpg)


